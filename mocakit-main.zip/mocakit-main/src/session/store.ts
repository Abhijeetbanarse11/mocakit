import { createHash } from 'node:crypto';

export interface SessionState {
  key: string;
  locale: string | null;
  createdAt: number;
}

/**
 * Pluggable session cache (e.g. file- or Redis-backed). Only the in-memory store ships.
 *
 * The stored values are live MOCA session keys: anyone who can read them can act as that user
 * until the session expires, so a persistent store must protect its values like credentials.
 *
 * Cache keys (see `sessionCacheKey`) are an unsalted sha256 hash of the URL, username and
 * password. A persistent store such as Redis or a file should restrict read access to its
 * keys, or re-hash the key with a secret before using it, since anyone who can read a key
 * and knows (or guesses) the URL/username can brute-force short passwords offline.
 *
 * `get`, `set` and `delete` are not atomic with respect to each other, and callers such as
 * `SessionManager#invalidate` build compare-then-delete on top of them (read the current
 * value, then delete only if it still matches). A Redis-backed implementation that wants to
 * close that race can additionally expose an atomic compare-and-delete (e.g. a Lua script or
 * `WATCH`/`MULTI`) for its own invalidate path.
 */
export interface SessionStore {
  get(cacheKey: string): Promise<SessionState | undefined>;
  set(cacheKey: string, state: SessionState): Promise<void>;
  delete(cacheKey: string): Promise<void>;
}

/**
 * States are stored by reference and are never evicted except when overwritten (by the next
 * login) or deleted by `invalidate`/`logout`; a stale entry found on lookup is left in place. That is acceptable for v1 (bounded by the number of distinct
 * credentials a process uses) but would need a TTL or LRU policy for long-lived, high-cardinality
 * use.
 */
export class MemorySessionStore implements SessionStore {
  readonly #sessions = new Map<string, SessionState>();

  async get(cacheKey: string): Promise<SessionState | undefined> {
    return this.#sessions.get(cacheKey);
  }

  async set(cacheKey: string, state: SessionState): Promise<void> {
    this.#sessions.set(cacheKey, state);
  }

  async delete(cacheKey: string): Promise<void> {
    this.#sessions.delete(cacheKey);
  }
}

/** Process-wide store shared by every client that has `session.reuse` enabled (the default). */
export const sharedSessionStore = new MemorySessionStore();

export function sessionCacheKey(url: string, username: string, password: string): string {
  return createHash('sha256').update(JSON.stringify([url, username, password])).digest('hex');
}
