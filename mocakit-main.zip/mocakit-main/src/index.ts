import type { MocaRow } from './types.js';

export {
  ApiClient,
  defineApi,
  type ApiCallOptions,
  type ApiFullOptions,
  type ApiFullResult,
  type ApiOperationSpec,
  type ApiParams,
  type ApiRowsOptions,
  type ApiSpecTable,
} from './client/api.js';
export { MOCA_STATUS, MocaClient, type MocaClientDeps } from './client/client.js';
export {
  defineCommands,
  type BatchBuilder,
  type BatchStep,
  type Command,
  type OptionalArgsCommand,
} from './client/commands.js';
export type { Query, QueryFilter, QueryRowsOptions } from './client/query.js';
export { formatMocaDate, parseMocaDate } from './dates/codec.js';
export {
  defineConfig,
  type ApiConfig,
  type CommandDocsConfig,
  type ContextConfig,
  type DecompilerConfig,
  type JavaConfig,
  type MocakitConfig,
  type SchemaConfig,
} from './define-config.js';
export {
  MocaApiError,
  MocaArgumentError,
  MocaAuthError,
  MocaCommandError,
  MocaError,
  MocaProtocolError,
  MocaTransportError,
  isMocaStatus,
} from './errors.js';
export { MemorySessionStore, sharedSessionStore, type SessionState, type SessionStore } from './session/store.js';
export { httpTransport, type Transport, type TransportRequest } from './transport/http.js';
export { httpRestTransport, type RestRequest, type RestResponse, type RestTransport } from './transport/rest.js';
export type {
  ArgSpec,
  BatchOptions,
  CallOptions,
  ClientDefaults,
  CommandSpec,
  FullOptions,
  MocaArgValue,
  MocaColumn,
  MocaConfig,
  MocaResult,
  MocaRow,
  MocaValue,
  NoArgs,
  RowsOptions,
  SessionInfo,
} from './types.js';
export { VERSION } from './version.js';

/**
 * Registry of known output row shapes, keyed by MOCA command name. Extend it with module augmentation:
 *
 * ```ts
 * declare module 'mocakit' {
 *   interface MocaOutputs { 'list orders': { ordnum: string; ordqty: number } }
 * }
 * ```
 */
// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface MocaOutputs {}

/** Row type for a command: its registered shape, or `MocaRow`. */
export type Output<C extends string> = C extends keyof MocaOutputs ? MocaOutputs[C] : MocaRow;
